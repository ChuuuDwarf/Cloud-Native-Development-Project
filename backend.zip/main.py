from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes.samples import router as samples_router
from app.routes.transfers import router as transfers_router
from app.routes.wips import router as wips_router
from app.routes.others import router as others_router

app = FastAPI(
    title="LIMS Backend",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(samples_router)
app.include_router(wips_router)
app.include_router(transfers_router)
app.include_router(others_router)


@app.get("/")
def root():
    return {"message": "LIMS backend is running"}